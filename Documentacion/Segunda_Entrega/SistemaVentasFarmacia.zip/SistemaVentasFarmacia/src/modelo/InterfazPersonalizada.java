package modelo;
/**
 *Interfaz personalizada para el metodo que sirve para limpiar los Texfield
 */
public interface InterfazPersonalizada {
    
    void Limpiar();
    
}
