package modelo;

/**
 * Clase Padre Persona
 */
public class Persona {
    private int idPersona;
    private String nombre;
    private String apellido;
    private int edad;
    private long telefono;
    private String direccion;
    private int estado;

    /**
     * Constructor de la clase padrePersona
     * 
     * @param idPersona
     * @param nombre
     * @param apellido
     * @param edad
     * @param telefono
     * @param direccion
     * @param estado 
     */
    public Persona(int idPersona, String nombre, String apellido, int edad, long telefono, String direccion, int estado) {
        this.idPersona = idPersona;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.telefono = telefono;
        this.direccion = direccion;
        this.estado = estado;
    }
    
    /**
     * Constructor vacio de la clase padre Persona
     */
    public Persona(){
    }

    //Getters y Setters de la clase
    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public long getTelefono() {
        return telefono;
    }

    public void setTelefono(long telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    
}
