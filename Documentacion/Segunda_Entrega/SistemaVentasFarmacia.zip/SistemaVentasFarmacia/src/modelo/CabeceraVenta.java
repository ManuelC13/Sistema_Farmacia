package modelo;

/**
 * Clase modelo que contiene atributos para las facturas de venta
 */
public class CabeceraVenta {
    
    //Atributos
    private int idCabeceraventa;
    private int idCliente;
    private double valorPagar;
    private String fechaVenta;
    private int estado;
    
    /**
     * Constructor de la clase CabeceraVenta
     */
    public CabeceraVenta(){
        this.idCabeceraventa = 0;
        this.idCliente = 0;
        this.valorPagar = 0.0;
        this.fechaVenta = "";
        this.estado = 0;
    }
   
    /**
     * Constructor sobre-cargado de la clase CabeceraVenta
     * 
     * @param idCabeceraventa
     * @param idCliente
     * @param valorPagar
     * @param fechaVenta 
     * @param estado 
     */

    public CabeceraVenta(int idCabeceraventa, int idCliente, double valorPagar, String fechaVenta, int estado) {
        this.idCabeceraventa = idCabeceraventa;
        this.idCliente = idCliente;
        this.valorPagar = valorPagar;
        this.fechaVenta = fechaVenta;
        this.estado = estado;
    }
    
    //Getters y setters de la clase 

    public int getIdCabeceraventa() {
        return idCabeceraventa;
    }

    public void setIdCabeceraventa(int idCabeceraventa) {
        this.idCabeceraventa = idCabeceraventa;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public double getValorPagar() {
        return valorPagar;
    }

    public void setValorPagar(double valorPagar) {
        this.valorPagar = valorPagar;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    
    //toString 
    
    
    /**
     * Metodo toString de la clase CabeceraVenta
     * @return la  cabecera de venta: idCabeceraVenta, idCliente, valorPagar,fechaVenta y estado
     */
    @Override
    public String toString() {
        return "CabeceraVenta{" + "idCabeceraventa=" + idCabeceraventa + ", idCliente=" + idCliente + ", valorPagar=" + valorPagar + ", fechaVenta=" + fechaVenta + ", estado=" + estado + '}';
    }
    
    
    
}
