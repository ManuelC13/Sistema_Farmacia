package modelo;

/**
 * Clase Usuario que hereda de la clase padre Persona
 */
public class Usuario extends Persona {
    private int idUsuario;
    private String usuario;
    private String contraseña;
    
    /**
     * Constructor de la clase Usuario
     * 
     * @param idUsuario
     * @param usuario
     * @param contraseña
     * @param idPersona
     * @param nombre
     * @param apellido
     * @param edad
     * @param telefono
     * @param direccion
     * @param estado 
     */
    public Usuario(int idUsuario, String usuario, String contraseña, int idPersona, String nombre, String apellido, int edad, int telefono, String direccion, int estado) {
        super(idPersona, nombre, apellido, edad, telefono, direccion, estado);
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

    /**
     * Constructor vacio de la clase Usuario
     */
    public Usuario() {
    }
    
    //Getters y Setters de la clase
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
}
