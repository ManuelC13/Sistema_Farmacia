package modelo;

/**
 * Clase modelo para las categorias de los produtos
 */
public class Categoria {

    private int idCategoria;
    private String descripcion;
    private int estado;
    
    /**
     * Constructor  de la clase Categoria que inicializa los atributos de la clase
     */
    public Categoria() {
        this.idCategoria = 0;
        this.descripcion = null;
        this.estado = 0;
    }

    /**
     * Constructor de la clase Categoria
     * @param idCategoria
     * @param descripcion
     * @param estado 
     */
    public Categoria(int idCategoria, String descripcion, int estado) {
        this.idCategoria = idCategoria;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    //Getters y setters de la clase
    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

}
