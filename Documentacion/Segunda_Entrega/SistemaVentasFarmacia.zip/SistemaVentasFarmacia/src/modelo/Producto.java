package modelo;

/**
 * Clase Producto que contiene los atributos de los productos
 */
public class Producto {
    
    private int idProducto;
    private int codigo;
    private String nombre;
    private int cantidad;
    private int idCategoria;
    private double precio;
    private boolean receta;
    private String fechaVen;
    private int estado;
    
    /**
     * Constructor que inicializa los valores de los atributos de la clase Producto
     */
    public Producto(){
        this.idProducto = 0;
        this.codigo = 0;
        this.nombre = "";
        this.cantidad = 0;
        this.idCategoria = 0;
        this.precio = 0.0; 
        this.receta = false;
        this.fechaVen = "";
        this.estado = 0;
    }

    /**
     * Constructor de la clase Producto
     * 
     * @param idProducto
     * @param codigo
     * @param nombre
     * @param cantidad
     * @param idCategoria
     * @param precio
     * @param porcentajeIva
     * @param receta
     * @param fechaVen
     * @param estado 
     */
    public Producto(int idProducto, int codigo, String nombre, int cantidad, int idCategoria, double precio, int porcentajeIva, boolean receta, String fechaVen, int estado) {
        this.idProducto = idProducto;
        this.codigo = codigo;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.idCategoria = idCategoria;
        this.precio = precio;
        this.receta = receta;
        this.fechaVen = fechaVen;
        this.estado = estado;
    }
    
    //Getters y Setters de la clase 
    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean isReceta() {
        return receta;
    }

    public void setReceta(boolean receta) {
        this.receta = receta;
    }

    public String getFechaVen() {
        return fechaVen;
    }

    public void setFechaVen(String fechaVen) {
        this.fechaVen = fechaVen;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
}
