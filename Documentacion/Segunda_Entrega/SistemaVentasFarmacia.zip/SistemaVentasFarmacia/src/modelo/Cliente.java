package modelo;

/**
 * Clase modelo Cliente que hereda de la clase padre Persona
 */
public class Cliente extends Persona {

    private int idCliente;
    private int clienteAmigo;
    
    /**
     * Construcotor de la clase Cliente
     * 
     * @param idCliente
     * @param clienteAmigo
     * @param idPersona
     * @param nombre
     * @param apellido
     * @param edad
     * @param telefono
     * @param direccion
     * @param estado 
     */
    public Cliente(int idCliente, int clienteAmigo, int idPersona, String nombre, String apellido, int edad, int telefono, String direccion, int estado) {
        super(idPersona, nombre, apellido, edad, telefono, direccion, estado);
        this.idCliente = idCliente;
        this.clienteAmigo = clienteAmigo;
    }
    
    /**
     * Constructor vacio de la clase modelo Cliente
     */
    public Cliente(){
    }
    
    //Getters y setters de la clase
    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getClienteAmigo() {
        return clienteAmigo;
    }

    public void setClienteAmigo(int clienteAmigo) {
        this.clienteAmigo = clienteAmigo;
    }
    

}
