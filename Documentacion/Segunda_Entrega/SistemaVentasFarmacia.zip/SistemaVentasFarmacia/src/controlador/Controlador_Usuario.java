package controlador;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

import modelo.Usuario;
import conexion.Conexion;

/**
 * Clase que controla el inicio de sesion del usuario.
 * Valida las credenciales del usuario con los usuarios registrados en la base de datos.
 */
public class Controlador_Usuario {
    
    //metodo para iniciar sesion
    public boolean iniciarSesion(Usuario usuario){
        
        boolean respuesta = false;
        Connection conexion = Conexion.conectar();
        String sql = "select usuario, password from tb_usuario where usuario = '" + usuario.getUsuario() + "' and password = '" + usuario.getContraseña() + "'";
        Statement st;
        
        try {
            st = (Statement) conexion.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                respuesta = true;
            }
            
        } catch (SQLException e){
            System.out.println("Error al iniciar sesion");
            JOptionPane.showMessageDialog(null, "Error al iniciar sesion");
        }
        
        return respuesta;
    }
}
