package conexion;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

/**
 * Clase que hace la conexion a la base de datos 
 */
public class Conexion {
    
    //conexion local
    public static Connection conectar(){
        try {
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/bd_farmacia", "root","123456789");
            return conexion;
        } catch (SQLException e){
            System.out.println("Error en la conexion local" + e);
        }
        return null;
    }
    
}
